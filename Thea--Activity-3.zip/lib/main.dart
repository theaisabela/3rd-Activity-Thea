import 'package:flutter/material.dart';
// removed google_fonts for flutlab compatibility

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final violetSeed = Colors.deepPurpleAccent; // violet-ish seed

    final base = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: violetSeed),
      useMaterial3: true,
    );

    return MaterialApp(
      title: "Thea's Gown Rental",
      theme: base.copyWith(
        // use default fonts to keep compatibility with flutlab
        scaffoldBackgroundColor:
            const Color(0xFFF6F0FF), // soft violet background
        appBarTheme: base.appBarTheme.copyWith(backgroundColor: violetSeed),
        cardTheme: base.cardTheme.copyWith(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12))),
      ),
      home: const MainScaffold(),
    );
  }
}

class MainScaffold extends StatefulWidget {
  const MainScaffold({super.key});

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  int _selectedIndex = 0;

  static final List<Widget> _pages = <Widget>[
    const HomePage(),
    const AuthChoicePage(),
    const BookingPage(),
    const YourBookingsPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_selectedIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _onItemTapped,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.login), label: 'Login'),
          NavigationDestination(icon: Icon(Icons.event), label: 'Booking'),
          NavigationDestination(
              icon: Icon(Icons.book_online), label: 'Your Booking'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          Text(
            "Welcome to Thea's",
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            "Gown Rental Service",
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 20),
          const UsernameForm(),
        ],
      ),
    );
  }
}

class UsernameForm extends StatefulWidget {
  const UsernameForm({super.key});

  @override
  State<UsernameForm> createState() => _UsernameFormState();
}

class _UsernameFormState extends State<UsernameForm> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _controller,
                decoration: const InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  final username = _controller.text.trim();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text(
                            'Hello ${username.isEmpty ? 'Guest' : username}!')),
                  );
                },
                child: const Text('Save Username'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthChoicePage extends StatelessWidget {
  const AuthChoicePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 4,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text('Welcome back!',
                      style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 8),
                  Text('Please login or register to continue.',
                      style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (_) => const LoginFormScreen())),
                          child: const Text('Login'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (_) => const RegisterFormScreen())),
                          child: const Text('Register'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LoginFormScreen extends StatefulWidget {
  const LoginFormScreen({super.key});

  @override
  State<LoginFormScreen> createState() => _LoginFormScreenState();
}

class _LoginFormScreenState extends State<LoginFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      final email = _emailController.text.trim();
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Logged in as $email')));
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(labelText: 'Email'),
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please enter an email';
                          }
                          if (!v.contains('@')) {
                            return 'Email must contain @';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _passwordController,
                        decoration:
                            const InputDecoration(labelText: 'Password'),
                        obscureText: true,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please enter a password';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              onPressed: _submit, child: const Text('Login'))),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterFormScreen extends StatefulWidget {
  const RegisterFormScreen({super.key});

  @override
  State<RegisterFormScreen> createState() => _RegisterFormScreenState();
}

class _RegisterFormScreenState extends State<RegisterFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  String _role = 'User';

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Registered ${_nameController.text} as $_role')));
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller: _nameController,
                        decoration:
                            const InputDecoration(labelText: 'Full name'),
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please enter your name';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(labelText: 'Email'),
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please enter an email';
                          }
                          if (!v.contains('@')) {
                            return 'Email must contain @';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _passwordController,
                        decoration:
                            const InputDecoration(labelText: 'Password'),
                        obscureText: true,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please enter a password';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _confirmController,
                        decoration: const InputDecoration(
                            labelText: 'Confirm password'),
                        obscureText: true,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return 'Please confirm your password';
                          }
                          if (v != _passwordController.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _role,
                        decoration: const InputDecoration(labelText: 'Role'),
                        items: const [
                          DropdownMenuItem(value: 'User', child: Text('User')),
                          DropdownMenuItem(
                              value: 'Admin', child: Text('Admin')),
                        ],
                        onChanged: (v) {
                          setState(() {
                            _role = v ?? 'User';
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                              onPressed: _submit,
                              child: const Text('Register'))),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Booking {
  Booking({
    required this.name,
    required this.email,
    required this.phone,
    required this.gownType,
    required this.size,
    required this.date,
    required this.time,
    required this.alterations,
    required this.accessoryRental,
    required this.extendedRental,
    required this.specialRequests,
  });

  final String name;
  final String email;
  final String phone;
  final String gownType;
  final String size;
  final DateTime date;
  final TimeOfDay time;
  final bool alterations;
  final bool accessoryRental;
  final bool extendedRental;
  final bool specialRequests;
}

class BookingPage extends StatefulWidget {
  const BookingPage({super.key});

  @override
  State<BookingPage> createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  String _selectedGownType = 'Ball Gown';
  String _selectedSize = 'Small';
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _alterations = false;
  bool _accessoryRental = false;
  bool _extendedRental = false;
  bool _specialRequests = false;

  // Local in-memory storage for bookings
  static final List<Booking> _bookings = <Booking>[];

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now().subtract(const Duration(days: 0)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      setState(() {
        _selectedDate = date;
      });
    }
  }

  Future<void> _pickTime() async {
    final t =
        await showTimePicker(context: context, initialTime: _selectedTime);
    if (t != null) {
      setState(() {
        _selectedTime = t;
      });
    }
  }

  void _submitBooking() {
    final booking = Booking(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      phone: _phoneController.text.trim(),
      gownType: _selectedGownType,
      size: _selectedSize,
      date: _selectedDate,
      time: _selectedTime,
      alterations: _alterations,
      accessoryRental: _accessoryRental,
      extendedRental: _extendedRental,
      specialRequests: _specialRequests,
    );

    _bookings.add(booking);

    // Navigate to YourBookingsPage and show the saved booking
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const YourBookingsPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text("Gown Rental Booking",
                      style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 12),
                  TextField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                          labelText: 'Name', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                          labelText: 'Email', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(
                      controller: _phoneController,
                      decoration: const InputDecoration(
                          labelText: 'Phone Number',
                          border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _selectedGownType,
                    decoration:
                        const InputDecoration(labelText: 'Select Gown Type'),
                    items: const [
                      DropdownMenuItem(
                          value: 'Ball Gown', child: Text('Ball Gown')),
                      DropdownMenuItem(
                          value: 'Mermaid', child: Text('Mermaid')),
                      DropdownMenuItem(value: 'A-Line', child: Text('A-Line')),
                      DropdownMenuItem(value: 'Sheath', child: Text('Sheath')),
                    ],
                    onChanged: (v) =>
                        setState(() => _selectedGownType = v ?? 'Ball Gown'),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _selectedSize,
                    decoration: const InputDecoration(labelText: 'Select Size'),
                    items: const [
                      DropdownMenuItem(value: 'Small', child: Text('Small')),
                      DropdownMenuItem(value: 'Medium', child: Text('Medium')),
                      DropdownMenuItem(value: 'Large', child: Text('Large')),
                      DropdownMenuItem(
                          value: 'Extra Large', child: Text('Extra Large')),
                    ],
                    onChanged: (v) =>
                        setState(() => _selectedSize = v ?? 'Small'),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                          child: OutlinedButton(
                              onPressed: _pickDate,
                              child: Text(
                                  'Pick date: ${_selectedDate.toLocal().toString().split(' ')[0]}'))),
                      const SizedBox(width: 8),
                      Expanded(
                          child: OutlinedButton(
                              onPressed: _pickTime,
                              child: Text(
                                  'Pick time: ${_selectedTime.format(context)}'))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text('Additional Options:'),
                  CheckboxListTile(
                      value: _alterations,
                      onChanged: (v) =>
                          setState(() => _alterations = v ?? false),
                      title: const Text('Alterations')),
                  CheckboxListTile(
                      value: _accessoryRental,
                      onChanged: (v) =>
                          setState(() => _accessoryRental = v ?? false),
                      title: const Text('Accessory Rental')),
                  CheckboxListTile(
                      value: _extendedRental,
                      onChanged: (v) =>
                          setState(() => _extendedRental = v ?? false),
                      title: const Text('Extended Rental Period')),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Special Requests'),
                      Switch(
                          value: _specialRequests,
                          onChanged: (v) =>
                              setState(() => _specialRequests = v)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                      onPressed: _submitBooking,
                      child: const Text('Submit Booking')),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (_) => const YourBookingsPage())),
                    child: const Text('View Your Booking'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class YourBookingsPage extends StatelessWidget {
  const YourBookingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Access the static bookings from BookingPage state class
    final items = _BookingPageState._bookings;

    return Scaffold(
      appBar: AppBar(title: const Text('Your Bookings')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: items.isEmpty
            ? Center(
                child: Text('No bookings yet',
                    style: Theme.of(context).textTheme.bodyLarge))
            : ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, i) {
                  final b = items[i];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b.name,
                              style: Theme.of(context).textTheme.titleLarge),
                          const SizedBox(height: 6),
                          Text('Gown Type: ${b.gownType}'),
                          Text('Size: ${b.size}'),
                          Text(
                              'Date: ${b.date.toLocal().toString().split(' ')[0]} at ${b.time.format(context)}'),
                          const SizedBox(height: 6),
                          Text('Options: ${[
                            if (b.alterations) 'Alterations',
                            if (b.accessoryRental) 'Accessory Rental',
                            if (b.extendedRental) 'Extended Rental'
                          ].join(', ')}'),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
