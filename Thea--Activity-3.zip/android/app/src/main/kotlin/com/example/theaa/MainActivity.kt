package com.example.theaa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
